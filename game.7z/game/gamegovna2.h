#ifndef GAMEGOVNA2_H_INCLUDED
#define GAMEGOVNA2_H_INCLUDED

void  vragcos(int ti);
void kotanim();
void kotstate();
void proverkaanala();

#endif // GAMEGOVNA2_H_INCLUDED
