#include <SFML/Graphics.hpp>//подключение заголовочного файла
#include "gamegovna.h"
#include "gamegovna2.h"
using namespace sf;

int g=0 /*счетчик*/, vx[100], vy[100], randvrag[100]/*рандом картинок*/, konec=2;
int timenewvr=0, ground=1, timerjump=0, speed=20,fx=0,fy=0,State1=0; //это таймер создания новых врагов
Clock clock2; //время нужно для счета расстояния пройденного котом
Image figimage, vragimage;
    Texture figtexture,vragtexture;
    Sprite figsprite,vragsprite[101];
 float  chetanim=1,PosTek = 5;//хранит текущий кадр




int main()
{
    RenderWindow win(VideoMode(840, 580), "<->Bolt<->");//пространство имен создает окно
//сначала импортируем картинку из файла, затем в текстуру и в спрайт
     figimage.loadFromFile("image/kot2_negate.png");
    vragimage.loadFromFile("image/kak.png");
    vragtexture.loadFromImage(vragimage);
    figtexture.loadFromImage(figimage);
    figsprite.setTexture(figtexture);
    figsprite.setTextureRect(IntRect(0,0,111,110));//первый кадр
    figsprite.setPosition(50, 248);//начальная позиция

    Sprite tortsprite;
    tortsprite.setTexture(vragtexture);
    tortsprite.setTextureRect(IntRect(130,0,50,50));
    tortsprite.setPosition(920,310);

    Font font;//шрифт
	font.loadFromFile("image/CyrillicOld.ttf");
    Text text("", font, 20);
	text.setColor(Color::White);
	text.setStyle(Text::Bold);//стиль текста

    RectangleShape line(Vector2f(840, 1));//граница
    line.setPosition(0,360);//полоса

    vx[0]=1000; vy[0]=310; //объявляем положение первого врага


    while (win.isOpen() && Keyboard::isKeyPressed(Keyboard::Escape)<=0 )//пока открыто окно
    {
        int ti= clock2.getElapsedTime().asSeconds();
        ti*=25;

        Event event; //событие
        while (win.pollEvent(event))
        {
            if (event.type == Event::Closed)//закрыть если закрыли
                win.close();

        }
               kotanim();
            State1=statekot(State1);
            voidgovno(State1);
            kotstate();
         vragcos(ti); //создаем врага
        proverkaanala();

        Time tim=milliseconds(120);
        if(ti>300) tim-= milliseconds(ti/30); //уменьшаем таймер следовательно ускоряем игру
        sleep(tim);//делаем залипание с помощью этого таймера
        if (ti>2700) konec=3;//прописываем выигрыш

        win.clear();//очищает и затем рисует и показывает
        if (!konec){//если ничего нового не произошло то просто рисуем объекты и продолжаем играть

        win.draw(figsprite);
        win.draw(line);

        text.setPosition(0,10);//задаем позицию текста
        text.setCharacterSize(20);//размер текста
        text.setString("Kot Vasiliy");
        text.setPosition(0,10);//задаем позицию текста
        win.draw(text);//рисую этот текст

        //увелициваем размер и показываем другой текст
        text.setCharacterSize(24);
        text.setString(std::to_string(ti) + " sm");//расстояние пройденное котом в см
         text.setPosition(5,40);//задаем позицию текста
        win.draw(text);//рисую этот текст

        for (int i=0;i<100;i++)
         win.draw(vragsprite[i]);//рисуем весь массив врагов
        }

        else if (konec==3){// состояние игры победа=3
            text.setString("\t\t\t  You Win!");
            text.setCharacterSize(30);
            text.setPosition(200,100);

            if (tortsprite.getPosition().x > figsprite.getPosition().x+130) tortsprite.move(-20,0);//передвигаем торт до кота
            win.draw(text);
            win.draw(figsprite);
            win.draw(line);
            win.draw(tortsprite);
        }
        else { //состояние игры проигрыш=1 или первый запуск=2
        //основная задача все обнулить и ничего не выводить кроме текста
            if (konec==1){
            text.setString("\t\t\t  Game over\n To start first click space");
            }
            else text.setString("\t\t\tHi!\n To start first click space");
            text.setCharacterSize(40);
            text.setPosition(200,180);
            win.draw(text);
            nol();
            }

        win.display();
    }
    return 0;
}
