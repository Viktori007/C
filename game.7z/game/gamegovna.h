#ifndef GAMEGOVNA_H_INCLUDED
#define GAMEGOVNA_H_INCLUDED

int statekot(int State1);
void voidgovno(int State1);
void nol();

#endif // GAMEGOVNA_H_INCLUDED
